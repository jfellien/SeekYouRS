using Raven.Abstractions;
using Raven.Database.Linq;
using System.Linq;
using System.Collections.Generic;
using System.Collections;
using System;
using Raven.Database.Linq.PrivateExtensions;
using Lucene.Net.Documents;
using System.Globalization;
using System.Text.RegularExpressions;
using Raven.Database.Indexing;


public class Index_Auto_2fAggregateEventBags_2fByAggregateId : Raven.Database.Linq.AbstractViewGenerator
{
	public Index_Auto_2fAggregateEventBags_2fByAggregateId()
	{
		this.ViewText = @"from doc in docs.AggregateEventBags
select new { AggregateId = doc.AggregateId }";
		this.ForEntityNames.Add("AggregateEventBags");
		this.AddMapDefinition(docs => 
			from doc in docs
			where string.Equals(doc["@metadata"]["Raven-Entity-Name"], "AggregateEventBags", System.StringComparison.InvariantCultureIgnoreCase)
			select new {
				AggregateId = doc.AggregateId,
				__document_id = doc.__document_id
			});
		this.AddField("AggregateId");
		this.AddField("__document_id");
		this.AddQueryParameterForMap("AggregateId");
		this.AddQueryParameterForMap("__document_id");
		this.AddQueryParameterForReduce("AggregateId");
		this.AddQueryParameterForReduce("__document_id");
	}
}
