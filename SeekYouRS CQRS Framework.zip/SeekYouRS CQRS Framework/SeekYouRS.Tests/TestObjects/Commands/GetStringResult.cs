using System;

namespace SeekYouRS.Tests.TestObjects.Commands
{
	internal class GetStringResult
	{
		public Guid Id { get; set; }

		public string ExpectedResult { get; set; }
	}
}