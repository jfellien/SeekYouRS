using System;

namespace SeekYouRS.Tests.TestObjects.Commands
{
	internal class GetIntResult
	{
		public Guid Id { get; set; }

		public int ExpectedResult { get; set; }
	}
}