using System;

namespace SeekYouRS.Tests.TestObjects.Commands
{
	internal class CommandWithoutEventHandling
	{
		public Guid Id { get; set; }
	}
}