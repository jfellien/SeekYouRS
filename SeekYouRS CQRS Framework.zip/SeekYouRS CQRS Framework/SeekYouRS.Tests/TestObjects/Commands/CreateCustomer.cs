using System;

namespace SeekYouRS.Tests.TestObjects.Commands
{
    public class CreateCustomer
    {
        public string Name { get; set; }

        public Guid Id { get; set; }
    }
}