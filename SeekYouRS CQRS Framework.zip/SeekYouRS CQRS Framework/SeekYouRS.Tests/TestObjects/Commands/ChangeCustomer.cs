using System;

namespace SeekYouRS.Tests.TestObjects.Commands
{
    internal class ChangeCustomer
    {
        public string Name { get; set; }

        public Guid Id { get; set; }
    }
}