using System;

namespace SeekYouRS.Tests.TestObjects.Commands
{
	internal class CreateCustomerWithoutAggregatStore

	{
		public Guid Id { get; set; }

		public string Name { get; set; }
	}
}