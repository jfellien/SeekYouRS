using System;

namespace SeekYouRS.Tests.TestObjects.Commands
{
    internal class RemoveCustomer
    {
        public Guid Id { get; set; }
    }
}