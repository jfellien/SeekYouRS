using System;

namespace SeekYouRS.Tests.TestObjects.Commands
{
    public class CreateVehicle
    {
        public string Typ { get; set; }

        public Guid Id { get; set; }
    }
}