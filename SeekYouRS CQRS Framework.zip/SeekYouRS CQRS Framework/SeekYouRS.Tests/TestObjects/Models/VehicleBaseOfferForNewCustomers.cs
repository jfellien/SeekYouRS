using System;

namespace SeekYouRS.Tests.TestObjects.Models
{
	internal class VehicleBaseOfferForNewCustomers
	{
		public Guid CustomerId { get; set; }
	}
}