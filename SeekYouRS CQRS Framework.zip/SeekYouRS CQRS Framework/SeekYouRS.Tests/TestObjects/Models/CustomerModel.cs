using System;

namespace SeekYouRS.Tests.TestObjects.Models
{
    internal class CustomerModel
    {
        public string Name { get; set; }

        public Guid Id { get; set; }
    }
}