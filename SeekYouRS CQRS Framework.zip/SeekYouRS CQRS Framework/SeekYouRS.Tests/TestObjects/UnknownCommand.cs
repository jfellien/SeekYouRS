namespace SeekYouRS.Tests.TestObjects
{
	public class UnknownCommand{}
}