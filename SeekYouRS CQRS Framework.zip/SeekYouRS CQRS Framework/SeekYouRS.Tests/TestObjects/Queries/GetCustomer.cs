using System;

namespace SeekYouRS.Tests.TestObjects.Queries
{
    internal class GetCustomer
    {
        public Guid Id { get; set; }
    }
}