namespace SeekYouRS.Tests.TestObjects.Queries
{
    internal class GetAllCustomers 
    {
    }
}