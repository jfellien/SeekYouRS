using System;

namespace SeekYouRS.Tests.TestObjects
{
	class KlasseMitFeld
	{
		public Guid Id;

		public KlasseMitFeld(Guid id)
		{
			Id = id;
		}
	}
}